export interface UserDetails {
    userName: string;
    userFirstName: string;
    userLastName: string;
}